$(document).ready(function(){
	$("#slides").superslides({
		animation: "fade",
		play: "5000",
		pagination: false,

	});

	var typed = new Typed(".typed",{
	strings: ["Software Developer", "Fullstack Engeneer", "Web Designer", "Mobile App Developer", "student."],
	typeSpeed: 90,
	loop: true,
	startDelay: 1000,
	showCursor: false,
	})

	$('.owl-carousel').owlCarousel({
    loop:true,
    items: 4,
    responsive:{
        0:{
            items:1
        },
        400:{
            items:2
        },
        760:{
            items:3
        },
        938:{
            items:4
        },
    }
});

	 $('.chart').easyPieChart({
            easing: 'easeInOut',
            barColor: '#fff',
            trackColor: false,
            scaleColor: false,
            lineWidth: 4,
            size: 152,
            // onStep: function(from, to, percent) {
            // 	$(this.el).find('.percent').text(math.round(percent));
            // }
        });

	 // var skillsTopOffset = $(".skillsSection").offset().top;
  //     $(window).scroll(function){

  //     	if (window.pageYOffset >skillsTopOffset - &(window).height() + 200) {
      	
  //     });
  $(".counter").each(function(){
  	var element = $(this);
  	var endVal = parseInt(element.text());

  	element.countup(endVal);
  });
  $("data-fancybox").fancybox();

  $(".item").isotope({
  	filter: '*',
  	animationOptions: {
  		duration: 1500,
  		easing: 'linear',
  		queue: false,
  	}
  });
  $("#filter a").click(function() {
   
   $("#filter .current").removeClass("current")
   $(this).addClass("current");

   var selector = $(this).attr("data-filter");

     $(".items").isotope({
     filter: 'selector',
      animationOptions: {
      duration: 1500,
      easing: 'linear',
      queue: false,
    }
  });

     return false;
  });

  const nav = $("#navigation");
  const navTop = nav.offset().top;

  $(window).on("scroll", stickyNavigation);
  function stickyNavigation(){
    var body =$("body");

    if($(window).scrollTop() >= navTop) {
      body.addClass("fixedNav");
    }
    else {
      body.removeClass("fixedNav");
    }
  }
});